<?php

$all = curl_init();

curl_setopt($all, CURLOPT_URL, 'https://api.caw.sh/v3/covid-19/historical/kenya?lastdays=all');
curl_setopt($all, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($all, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($all, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($all, CURLOPT_SSL_VERIFYPEER, 0);

$headers = array();
$headers[] = 'Accept: application/json';
curl_setopt($all, CURLOPT_HTTPHEADER, $headers);

$result = curl_exec($all);
if (curl_errno($all)) {
    echo 'Error:' . curl_error($all);
}
$covidData =json_decode($result,true);
$cases =$covidData['timeline']['cases'];
$recovered = $covidData['timeline']['recovered'];
$deaths = $covidData['timeline']['deaths'];
$dates=$covidData['timeline'];






//7 days
$seven = curl_init();

curl_setopt($seven, CURLOPT_URL, 'https://api.caw.sh/v3/covid-19/historical/kenya?lastdays=7');
curl_setopt($seven, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($seven, CURLOPT_CUSTOMREQUEST, 'GET');
curl_setopt($seven, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($seven, CURLOPT_SSL_VERIFYPEER, 0);

$headers = array();
$headers[] = 'Accept: application/json';
curl_setopt($seven, CURLOPT_HTTPHEADER, $headers);

$resultSeven = curl_exec($seven);
if (curl_errno($seven)) {
    echo 'Error:' . curl_error($seven);
}
$covidDataSeven =json_decode($resultSeven,true);
$casesSeven =$covidDataSeven['timeline']['cases'];
$recoveredSeven = $covidDataSeven['timeline']['recovered'];
$deathsSeven = $covidDataSeven['timeline']['deaths'];
$datesSeven=$covidDataSeven['timeline'];






curl_close($all);
curl_close($seven);
//var_dump( $dates);

$allDate = "2020/1/22";

//echo date('d-M-y', strtotime($date. ' + 5 days'));

?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.0/dist/css/bootstrap.min.css" integrity="sha384-B0vP5xmATw1+K9KRQjQERJvTumQW0nPEzvF6L/Z6nronJ3oUOFUFpCjEUQouq2+l" crossorigin="anonymous">

<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.9.4/Chart.js"></script>


<div class="container-fluid" style="overflow: hidden;">
<div class="row">

<div class="col-lg-4 col-md-12 col-sm-12 " style="overflow-x: scroll;">
<h1>ALL RECORDS</h1>
<table class="table text-center">
    <thead class="thead-light text-uppercase">
        <tr>
        <th>Dates</th>
            <th>CASES</th>
            <th>Recovered</th>
            <th>DEATHS</th>
        </tr>
    </thead>
    <tbody>
        <tr>
        <td>
        <?php 
        for ($x = 0; $x <= count($cases); $x++) {
                     
        echo date('d-M-y', strtotime($allDate. ' + '.$x.' days'));
        echo '<br>';
        }
        ?>
        
        </td>
            <td><?php foreach ($cases as $case) { echo $case.'<br>'; }?></td>
            <td><?php  foreach ($recovered as $recover) { echo $recover.'<br>'; }?></td>
            <td><?php  foreach ($deaths as $death) { echo $death.'<br>'; } ?></td>
        </tr>
    </tbody>
    <tfoot>
        <tr>
            <th>#</th>
        </tr>
    </tfoot>
</table>

</div>

<div class="col-lg-6 col-xl-6 col-sm-12 col-md-12">
<br><br>
<h3>Cases Recorded </h3>
<span>From 22 Jan 2020</span>
<canvas id="cases" style="width:100%; height:80vh;" ></canvas>

<br><br>
<h3>Patients Recovered</h3>
<span>From 22 Jan 2020</span>

<canvas id="recover" style="width:100%; height:80vh;"></canvas>

<br><br>
<h3>Deaths Recorded</h3>
<span>From 22 Jan 2020</span>

<canvas id="death" style="width:100%; height:80vh;"></canvas>

<hr>
<hr>

</div>

<div class="col-lg-2 col-sm-12 col-md-12">
<br><br><br>
<h4>
<?php
echo date("l") . "<br>";
echo date("jS \of F Y "); 

$date = date("d-m-y");
$daySeven = date('d-M-y', strtotime($date. ' -5 days'));
// Prints the day, date, month, year, time, AM or PM



//echo $daySeven;

?>


</h4>



<br>
<h3>Deaths Recorded</h3>
<span>Last 7 days</span>
<canvas id="casesSeven" style="width:100%; "></canvas>

<br><br>
<h3>Recovery Recorded</h3>
<span>Last 7 days</span>
<canvas id="recoveredSeven" style="width:100%;"></canvas>



<br><br>
<h3>Death Recorded</h3>
<span>Last 7 days</span>
<canvas id="deathsSeven" style="width:100%;"></canvas>
<hr>
</div>




</div>

</div>




<script>



var xValuesCases = [<?php 
        for ($x = 0; $x <= count($cases); $x++) {
                     echo date('dmy', strtotime($allDate. ' + '.$x.' days'));echo ',';
        }
        ?>];
var yValuesCases = [<?php foreach ($cases as $case) { echo $case.','; }?>];

new Chart("cases", {
  type: "line",
  data: {
    labels: xValuesCases,
    datasets: [{
      label: 'Cases',
      fill: true,
      lineTension: 1,
      borderColor: 'rgb(75, 192, 192)',
      data: yValuesCases
    }]
  },
  options: {
    legend: {display: true},
    scales: {
      yAxes: [{ticks: {min: 0, max:200000}}],
    }
  }
});







var xValuesRecovered = [<?php 
        for ($x = 0; $x <= count($cases); $x++) {
                     echo date('dmy', strtotime($allDate. ' + '.$x.' days'));echo ',';
        }
        ?>];
var yValuesRecovered = [<?php foreach ($recovered as $recover) { echo $recover.','; }?>];

new Chart("recover", {
  type: "line",
  data: {
    labels: xValuesRecovered,
    datasets: [{
      label: 'Recovered',
      fill: true,
      lineTension: 1,
      borderColor: '#6f42c1',
      data: yValuesRecovered
    }]
  },
  options: {
    legend: {display: true},
    scales: {
      yAxes: [{ticks: {min: 0, max:150000}}],
    }
  }
});




var xValuesDeath = [<?php 
        for ($x = 0; $x <= count($cases); $x++) {
                     echo date('dmy', strtotime($allDate. ' + '.$x.' days'));echo ',';
        }
        ?>];
var yValuesDeath = [<?php foreach ($deaths as $death) { echo $death.','; }?>];

new Chart("death", {
  type: "line",
  data: {
    labels: xValuesDeath,
    datasets: [{
      label: 'Deaths',
      fill: true,
      lineTension: 1,
      borderColor: '#dc3545',
      data: yValuesDeath
    }]
  },
  options: {
    legend: {display: true},
    scales: {
      yAxes: [{ticks: {min: 0, max:3500}}],
    }
  }
});


var xValuesCasesSeven = [<?php 
        for ($x = 0; $x <= count($casesSeven); $x++) {
                     echo date('d', strtotime($daySeven. ' + '.$x.' days'));echo ',';
        }
        ?>];
var yValuesCasesSeven = [<?php foreach ($casesSeven as $caseSevens) { echo $caseSevens.','; }?>];

new Chart("casesSeven", {
  type: "line",
  data: {
    labels: xValuesCasesSeven,
    datasets: [{
      label: 'Cases',
      fill: true,
      lineTension: 1,
      borderColor: 'rgb(75, 192, 192)',
      data: yValuesCasesSeven
    }]
  },
  options: {
    legend: {display: true},
    scales: {
      yAxes: [{ticks: {min: 0, max:200000}}],
    }
  }
});


var xValuesRecoveredSeven = [<?php 
        for ($x = 0; $x <= count($casesSeven); $x++) {
                     echo date('d', strtotime($daySeven. ' + '.$x.' days'));echo ',';
        }
        ?>];
var yValuesRecoveredSeven = [<?php foreach ($recoveredSeven as $recoverSevens) { echo $recoverSevens.','; }?>];

new Chart("recoveredSeven", {
  type: "line",
  data: {
    labels: xValuesRecoveredSeven,
    datasets: [{
      label: 'Recovered',
      fill: true,
      lineTension: 1,
      borderColor: '#6f42c1',
      data: yValuesRecoveredSeven
    }]
  },
  options: {
    legend: {display: true},
    scales: {
      yAxes: [{ticks: {min: 0, max:150000}}],
    }
  }
});



var xValuesDeathsSeven =[<?php 
        for ($x = 0; $x <= count($casesSeven); $x++) {
                     echo date('d', strtotime($daySeven. ' + '.$x.' days'));echo ',';
        }
        ?>];
var yValuesDeathsSeven = [<?php foreach ($deathsSeven as $deathsSevens) { echo $deathsSevens.','; }?>];

new Chart("deathsSeven", {
  type: "line",
  data: {
    labels: xValuesDeathsSeven,
    datasets: [{
      label: 'Deaths',
      fill: true,
      lineTension: 1,
      borderColor: '#dc3545',
      data: yValuesDeathsSeven
    }]
  }, 
  options: {
    legend: {display: true},
    scales: {
      yAxes: [{ticks: {min: 0, max:4000}}],
    }
  }
});





</script>


