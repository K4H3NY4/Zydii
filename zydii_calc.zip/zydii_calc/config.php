<?php
$db = new mysqli( "localhost","root","","zydii");
if($db ->connect_error){
    exit("Cannot connect to the database");
}

?>