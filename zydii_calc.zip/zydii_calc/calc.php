<?php

include('config.php');
error_reporting(E_ALL ^ E_NOTICE);

if (isset($_POST['submit'])){
		
    $a= mysqli_real_escape_string ($db, $_POST['a']);
	$b = mysqli_real_escape_string ($db, $_POST['b']);
	$operation = mysqli_real_escape_string ($db, $_POST['operation']);

    // API URL
$url = 'http://127.0.0.1:8000/api/vuvuzela';

// Create a new cURL resource
$ch = curl_init($url);

// Setup request to send json via POST
$data = array(
    'a' => $a,
    'b' => $b,
    'operation' => $operation
); 


//$data = http_build_query

$postdata = json_encode($data);

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
//print_r ($result);
    

}else{}


?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container" a>
  <h2>Calculator Page</h2>
  <form action="" method="POST">
    <div class="form-group">
      <label for="numbera">Number A:</label>
      <input type="number" class="form-control" id="email" placeholder="Enter A" name="a">
    </div>
    <div class="form-group">
      <label for="pwd">Number B;</label>
      <input type="numberB" class="form-control" id="pwd" placeholder="Enter B" name="b">
    </div>
    <div class="select">
    <label for="pwd">Operation;</label>
    <select class="form-select" name="operation" aria-label="Default select example">
    <option value="enter operation">Enter operation</option>

  <option value="multiply">*</option>
  <option value="add">+</option>
  <option value="subtract">-</option>
  <option value="divide">/</option>
</select>
    </div>
    <button type="submit" class="btn btn-default" name="submit">Submit</button>
  </form>
</div>
<p align="center" style="font-size: 6em;">
<?php

print_r ($result);

?>


</p>

</body>
</html>
